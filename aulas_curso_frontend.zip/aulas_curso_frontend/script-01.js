function dataHora(){
        document.getElementById('demo').innerHTML = Date();
}

function dataHora02(id){
        document.getElementById(id).innerHTML= Date();
}